import DateCounter from '@/components/DateCounter';
import IconDribbble from '@/components/Icons/IconDribbble';
import IconInstagram from '@/components/Icons/IconInstagram';
import IconLinkedin from '@/components/Icons/IconLinkedin';
import IconTwitter from '@/components/Icons/IconTwitter';
import IconUpLeftArrow from '@/components/Icons/IconUpLeftArrow';
import Image from 'next/image';
import helper from '@/libs/helper';
import type { Metadata } from 'next';

export const metadata: Metadata = {
    title: 'NFT | Blockchain',
    description: 'Invest in creators & get unique NFT',
    openGraph: {
        ...helper.openGraphData,
        title: 'NFT | Blockchain',
        description: 'Invest in creators & get unique NFT',
        url: process.env.NEXT_PUBLIC_APP_URL + '/nft',
        type: 'website',
    },
    twitter: {
        ...helper.twitterData,
        title: 'NFT | Blockchain',
        description: 'Invest in creators & get unique NFT',
    },
    alternates: {
        canonical: `${process.env.NEXT_PUBLIC_APP_URL}/nft`,
        languages: { 'x-default': `${process.env.NEXT_PUBLIC_APP_URL}/nft` },
    },
};

const page = () => {
    return (
        <div className="relative z-1 w-full overflow-hidden pb-5 lg:pl-[300px] lg:pr-4">
            <div className="container">
                <div className="grid gap-5 pt-14 xl:grid-cols-2 xl:pt-9">
                    <div className="xl:pt-24 2xl:w-4/5">
                        <div className="text-center xl:text-left">
                            <h1
                                className="mb-6 text-4xl font-semibold leading-tight! md:text-5xl xl:pr-10"
                                data-aos="zoom-in"
                                data-aos-duration="1000"
                                data-aos-delay="800"
                            >
                                <span className="animate-text bg-linear-to-r from-[#9A42FE] to-[#23EF9B] bg-clip-text text-transparent">
                                    Invest in creators{` `}
                                </span>
                                & get unique NFT
                            </h1>
                            <p className="font-light leading-7 opacity-40">The platform helps investors to make easy to purchase and sell their NFT tokens</p>
                        </div>
                        <DateCounter />
                    </div>
                    <div className="mx-auto pt-10 xl:ml-auto xl:mr-0 xl:pr-16 xl:pt-0 w-full xl:w-auto">
                        <div className="relative mx-auto overflow-hidden rounded-b-full bg-linear-to-b from-secondary/25 to-primary/25 p-4 sm:h-[414px] sm:w-64 sm:overflow-visible xl:ml-auto">
                            <Image
                                src="/assets/images/line-background.png"
                                alt="line-background"
                                className="absolute left-24 -top-2"
                                data-aos="fade-left"
                                data-aos-duration="2000"
                                data-aos-delay="800"
                                width={256}
                                height={311}
                            />
                            <Image
                                src="/assets/images/nft-1.png"
                                alt="nft-1"
                                className="top-4 -left-40 mx-auto sm:absolute"
                                data-aos="fade-down"
                                data-aos-duration="2000"
                                data-aos-delay="800"
                                width={256}
                                height={312}
                                style={{ width: '100%' }}
                            />
                            <Image
                                src="/assets/images/nft-2.png"
                                alt="nft-2"
                                className="-bottom-12 -right-16 mx-auto mt-4 sm:absolute sm:mt-0"
                                data-aos="fade-up"
                                data-aos-duration="2000"
                                data-aos-delay="800"
                                width={181}
                                height={210}
                            />
                            <div className="group absolute left-2 -bottom-14 hidden h-28 w-28 shrink-0 items-center justify-center rounded-full border border-[#9E9E9E] p-1 duration-300 hover:border-primary hover:text-primary xl:-mt-6 xl:inline-flex">
                                <Image
                                    src="/assets/images/your-creative-partner-txt.png"
                                    alt="your-creative-partner-txt"
                                    className="animate-spin-slow"
                                    width={102}
                                    height={102}
                                />
                                <span className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 duration-300 group-hover:scale-90">
                                    <IconUpLeftArrow />
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="py-14 sm:py-28">
                    <h2 className="pb-16 text-center text-4xl font-semibold" data-aos="zoom-in" data-aos-duration="1000">
                        Supported <span className="animate-text bg-linear-to-r from-secondary to-primary bg-clip-text text-transparent">Crypto Wallet</span>
                    </h2>
                    <div className="relative mx-auto grid max-w-4xl grid-cols-2 justify-between gap-y-8 gap-x-4 font-medium sm:grid-cols-4">
                        <div className="absolute top-10 left-1/2 hidden h-0.5 w-[calc(100%-170px)] -translate-x-1/2 rounded-full bg-linear-to-r from-secondary to-primary opacity-50 sm:block">
                            <span className="line-arrow-one absolute top-1/2 w-5 -translate-y-1/2">
                                <Image src="/assets/images/line-arrow.png" alt="line-arrow" width={20} height={19} />
                            </span>
                            <span className="line-arrow-two absolute top-1/2 w-5 -translate-y-1/2">
                                <Image src="/assets/images/line-arrow.png" alt="line-arrow" width={20} height={19} />
                            </span>
                        </div>
                        <div className="z-1 space-y-5 text-center">
                            <div className="inline-flex h-20 w-20 items-center justify-center rounded-full bg-[#3D391A]">
                                <Image src="/assets/images/bitcoin.svg" alt="bitcoin" className="animate-spin-slow" width={27} height={35} />
                            </div>
                            <h3>Bitcoin</h3>
                        </div>
                        <div className="z-1 space-y-5 text-center">
                            <div className="inline-flex h-20 w-20 items-center justify-center rounded-full bg-[#1A2923]">
                                <Image src="/assets/images/ethereum.svg" alt="ethereum" className="animate-spin-slow" width={23} height={44} />
                            </div>
                            <h3>Ethereum</h3>
                        </div>
                        <div className="z-1 space-y-5 text-center">
                            <div className="inline-flex h-20 w-20 items-center justify-center rounded-full bg-[#1A1A42]">
                                <Image src="/assets/images/teramox.svg" alt="teramox" className="animate-spin-slow" width={47} height={50} />
                            </div>
                            <h3>Teramox</h3>
                        </div>
                        <div className="z-1 space-y-5 text-center">
                            <div className="inline-flex h-20 w-20 items-center justify-center rounded-full bg-[#351222]">
                                <Image src="/assets/images/dogecoin.svg" alt="dogecoin" className="animate-spin-slow" width={38} height={35} />
                            </div>
                            <h3>Doge coin</h3>
                        </div>
                    </div>
                </div>
                <div className="rounded-[50px] bg-white/10 p-5 sm:p-10">
                    <div className="items-center border-white/10 py-4 sm:border-y-[3px] sm:py-12 xl:flex">
                        <div className="border-white/10 pt-10 pb-8 text-center xl:w-1/4 xl:border-r-[3px] xl:pt-16 xl:text-left">
                            <div className="relative inline-block pb-8 xl:pb-20" data-aos="zoom-out" data-aos-duration="1000">
                                <h2 className="inline-block bg-linear-to-r from-secondary to-primary bg-clip-text text-2xl font-medium text-transparent">
                                    Microverse
                                </h2>
                                <span className="absolute left-full bottom-full bg-linear-to-r from-secondary to-primary p-1 text-xl">Beta</span>
                            </div>
                            <h2 className="text-2xl font-semibold sm:text-4xl" data-aos="zoom-out" data-aos-duration="1000">
                                The hurricane creative
                            </h2>
                        </div>
                        <div className="space-y-6 text-center font-light leading-8 opacity-40 xl:w-3/4 xl:pl-10 xl:text-left xl:text-[22px]">
                            <p>
                                Where do NFTs go for a good time? The Microverse, obviously! Think of our world builder tool as a magic wand, where you flick
                                your wrist a few times and watch in wonder as your own 2D world comes to life.
                            </p>
                            <p>Your fans deserve a hangout as creative as they are, so drop into the Microverse and build it for them!</p>
                        </div>
                    </div>
                </div>
                <div className="py-16 md:py-28">
                    <div className="pb-10 text-center md:pb-24">
                        <h2 className="pb-8 text-4xl font-semibold" data-aos="zoom-in" data-aos-duration="1000">
                            How <span className="animate-text bg-linear-to-r from-secondary to-primary bg-clip-text text-transparent">It Works?</span>
                        </h2>
                        <p className="opacity-50">Crypterium blockchain is most popular way to buy and sell cryptocurrency & NFTS.</p>
                    </div>
                    <div className="relative mx-auto flex max-w-2xl flex-wrap justify-center gap-y-10 gap-x-4 md:justify-between xl:max-w-[974px] 2xl:max-w-6xl">
                        <div className="relative w-36 text-center">
                            <div className="mb-7 inline-flex h-28 w-28 items-center justify-center rounded-full bg-linear-to-b from-white/10 to-white/5">
                                <Image src="/assets/images/wallet.svg" alt="wallet" width={48} height={48} />
                            </div>
                            <h3>Set up your wallet</h3>
                            <div className="dotted-animation absolute top-14 left-full hidden w-7 md:block xl:w-32 2xl:w-48"></div>
                        </div>
                        <div className="relative w-36 text-center">
                            <div className="mb-7 inline-flex h-28 w-28 items-center justify-center rounded-full bg-linear-to-b from-white/10 to-white/5">
                                <Image src="/assets/images/collection.svg" alt="collection" width={48} height={48} />
                            </div>
                            <h3>Create your collection</h3>
                            <div className="dotted-animation absolute top-14 left-full hidden w-7 md:block xl:w-32 2xl:w-48"></div>
                        </div>
                        <div className="relative w-36 text-center">
                            <div className="mb-7 inline-flex h-28 w-28 items-center justify-center rounded-full bg-linear-to-b from-white/10 to-white/5">
                                <Image src="/assets/images/add.svg" alt="add" width={48} height={48} />
                            </div>
                            <h3>Add your NFTs</h3>
                            <div className="dotted-animation absolute top-14 left-full hidden w-7 md:block xl:w-32 2xl:w-48"></div>
                        </div>
                        <div className="w-36 text-center">
                            <div className="mb-7 inline-flex h-28 w-28 items-center justify-center rounded-full bg-linear-to-b from-white/10 to-white/5">
                                <Image src="/assets/images/sale.svg" alt="sale" width={49} height={48} />
                            </div>
                            <h3>List them for sale</h3>
                        </div>
                    </div>
                </div>
                <div>
                    <div className="pb-16 text-center">
                        <h2 className="pb-8 text-4xl font-semibold" data-aos="zoom-in" data-aos-duration="1000">
                            Our <span className="animate-text bg-linear-to-r from-secondary to-primary bg-clip-text text-transparent">Collections</span>
                        </h2>
                        <p className="opacity-50">Explore our newly released NFT collections</p>
                    </div>
                    <div className="grid gap-8 sm:grid-cols-3">
                        <div className="flex flex-col gap-8">
                            <div className="group overflow-hidden rounded-2xl sm:h-3/5">
                                <Image
                                    src="/assets/images/collection-1.jpg"
                                    alt="collection-1"
                                    className="h-full w-full object-cover duration-500 group-hover:scale-110"
                                    width={474}
                                    height={414}
                                />
                            </div>
                            <div className="group overflow-hidden rounded-2xl sm:h-2/5">
                                <Image
                                    src="/assets/images/collection-2.jpg"
                                    alt="collection-2"
                                    className="h-full w-full object-cover duration-500 group-hover:scale-110"
                                    width={474}
                                    height={276}
                                />
                            </div>
                        </div>
                        <div className="group overflow-hidden rounded-2xl">
                            <Image
                                src="/assets/images/collection-3.jpg"
                                alt="collection-3"
                                className="h-full w-full object-cover duration-500 group-hover:scale-110"
                                width={474}
                                height={722}
                            />
                        </div>
                        <div className="flex flex-col gap-8">
                            <div className="group overflow-hidden rounded-2xl sm:h-2/5">
                                <Image
                                    src="/assets/images/collection-4.jpg"
                                    alt="collection-4"
                                    className="h-full w-full object-cover duration-500 group-hover:scale-110"
                                    width={474}
                                    height={276}
                                />
                            </div>
                            <div className="group overflow-hidden rounded-2xl sm:h-3/5">
                                <Image
                                    src="/assets/images/collection-5.jpg"
                                    alt="collection-5"
                                    className="h-full w-full object-cover duration-500 group-hover:scale-110"
                                    width={474}
                                    height={414}
                                />
                            </div>
                        </div>
                    </div>
                </div>
                <div className="py-14 md:pt-28 md:pb-20">
                    <div className="flex flex-col items-center gap-5 pb-14 sm:flex-row sm:justify-between">
                        <div className="flex flex-col items-center gap-8 xl:flex-row xl:items-center" data-aos="fade-left" data-aos-duration="2000">
                            <span className="text-4xl font-semibold">Partners /</span>
                            <span className="opacity-50">Related projects & partner</span>
                        </div>
                        <div className="inline-block rounded-lg bg-linear-to-r from-secondary to-primary p-0.5">
                            <button
                                type="button"
                                className="wallet-btn group relative rounded-lg bg-black px-9 py-4 duration-500 after:absolute after:top-0 after:left-0 after:z-[-1] after:h-full after:w-0 after:duration-300 hover:bg-transparent hover:text-white hover:after:left-auto hover:after:right-0 hover:after:w-full"
                            >
                                <span className="bg-linear-to-r from-secondary to-primary bg-clip-text text-transparent group-hover:bg-none group-hover:text-black">
                                    View all
                                </span>
                            </button>
                        </div>
                    </div>
                    <div className="grid grid-cols-2 items-center justify-center gap-6 border-y-[3px] border-white/10 py-10 md:grid-cols-4 md:py-20">
                        <a href="#" className="group">
                            <Image
                                src="/assets/images/partner-logo-1.svg"
                                alt="partner-logo-1"
                                className="mx-auto transition group-hover:scale-110"
                                data-aos="zoom-out"
                                data-aos-duration="2000"
                                width={210}
                                height={100}
                            />
                        </a>
                        <a href="#" className="group">
                            <Image
                                src="/assets/images/partner-logo-2.svg"
                                alt="partner-logo-2"
                                className="mx-auto transition group-hover:scale-110"
                                data-aos="zoom-out"
                                data-aos-duration="2000"
                                width={210}
                                height={100}
                            />
                        </a>
                        <a href="#" className="group">
                            <Image
                                src="/assets/images/partner-logo-3.svg"
                                alt="partner-logo-3"
                                className="mx-auto transition group-hover:scale-110"
                                data-aos="zoom-out"
                                data-aos-duration="2000"
                                width={210}
                                height={100}
                            />
                        </a>
                        <a href="#" className="group">
                            <Image
                                src="/assets/images/partner-logo-4.svg"
                                alt="partner-logo-4"
                                className="mx-auto transition group-hover:scale-110"
                                data-aos="zoom-out"
                                data-aos-duration="2000"
                                width={210}
                                height={100}
                            />
                        </a>
                    </div>
                    <div className="mt-14 items-center border-b-[3px] border-white/10 md:mt-24 xl:flex">
                        <div className="text-center xl:w-1/2 xl:text-left">
                            <h2 className="text-2xl leading-tight sm:text-4xl/10 2xl:w-2/3" data-aos="fade-down" data-aos-duration="1000">
                                The medium you need, the people you’ll love.
                            </h2>
                            <div className="inline-flex flex-wrap justify-center gap-6 pt-14 xl:justify-start">
                                <div className="rounded-lg bg-linear-to-r from-secondary to-primary p-0.5">
                                    <button
                                        type="button"
                                        className="wallet-btn group relative rounded-lg bg-black px-6 py-4 duration-500 after:absolute after:top-0 after:left-0 after:z-[-1] after:h-full after:w-0 after:duration-300 hover:bg-transparent hover:text-white hover:after:left-auto hover:after:right-0 hover:after:w-full"
                                    >
                                        <span className="bg-linear-to-r from-secondary to-primary bg-clip-text text-transparent group-hover:bg-none group-hover:text-black">
                                            NFT tags
                                        </span>
                                    </button>
                                </div>
                                <div className="rounded-lg bg-linear-to-r from-secondary to-primary p-0.5">
                                    <button
                                        type="button"
                                        className="wallet-btn group relative rounded-lg bg-black px-6 py-4 duration-500 after:absolute after:top-0 after:left-0 after:z-[-1] after:h-full after:w-0 after:duration-300 hover:bg-transparent hover:text-white hover:after:left-auto hover:after:right-0 hover:after:w-full"
                                    >
                                        <span className="bg-linear-to-r from-secondary to-primary bg-clip-text text-transparent group-hover:bg-none group-hover:text-black">
                                            Crypto tags
                                        </span>
                                    </button>
                                </div>
                                <div className="rounded-lg bg-linear-to-r from-secondary to-primary p-0.5">
                                    <button
                                        type="button"
                                        className="wallet-btn group relative rounded-lg bg-black px-6 py-4 duration-500 after:absolute after:top-0 after:left-0 after:z-[-1] after:h-full after:w-0 after:duration-300 hover:bg-transparent hover:text-white hover:after:left-auto hover:after:right-0 hover:after:w-full"
                                    >
                                        <span className="bg-linear-to-r from-secondary to-primary bg-clip-text text-transparent group-hover:bg-none group-hover:text-black">
                                            NFT community
                                        </span>
                                    </button>
                                </div>
                            </div>
                        </div>
                        <div className="relative mx-auto mt-10 grid h-[500px] w-full max-w-sm grid-cols-2 overflow-hidden rounded-t-full border-[3px] border-b-0 border-white/10 px-8 py-16 xl:ml-auto xl:mr-10 xl:mt-0">
                            <span className="absolute left-1/2 top-1/2 h-5 w-5 -translate-x-1/2 -translate-y-1/2 bg-[#0e0f12]"></span>
                            <a href="#" className="inline-flex items-center justify-center border-b-[3px] border-white/10 transition hover:text-primary">
                                <span className="sr-only">Dribbble</span>
                                <span data-aos="fade-down-right" data-aos-duration="2000">
                                    <IconDribbble />
                                </span>
                            </a>
                            <a
                                href="#"
                                className="inline-flex items-center justify-center border-b-[3px] border-l-[3px] border-white/10 transition hover:text-primary"
                            >
                                <span className="sr-only">Twitter</span>
                                <span data-aos="fade-down-left" data-aos-duration="2000">
                                    <IconTwitter />
                                </span>
                            </a>
                            <a href="#" className="inline-flex items-center justify-center transition hover:text-primary">
                                <span className="sr-only">Linkedin</span>
                                <span data-aos="fade-up-right" data-aos-duration="2000">
                                    <IconLinkedin />
                                </span>
                            </a>
                            <a href="#" className="inline-flex items-center justify-center border-l-[3px] border-white/10 transition hover:text-primary">
                                <span className="sr-only">Instagram</span>
                                <span data-aos="fade-up-left" data-aos-duration="2000">
                                    <IconInstagram />
                                </span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default page;
