import App from '@/App';
import Header from '@/components/Layouts/Header';
import Sidebar from '@/components/Layouts/Sidebar';
import Lottieplayer from '@/components/Lottieplayer';
import '@/styles/app.css';
import type { Metadata } from 'next';
import helper from '@/libs/helper';

export const metadata: Metadata = {
    metadataBase: new URL(process.env.NEXT_PUBLIC_APP_URL || ''),
    title: 'Blockchain',
    description: 'The cryptocurrency exchange of trust for individual and institutional traders & investors. An ethereum token backed by a human individual.',
    openGraph: {
        ...helper.openGraphData,
        type: 'website',
    },
    icons: {
        icon: '/favicon.svg',
    },
    robots: {
        index: process.env.NEXT_PUBLIC_IS_PRODUCTION == 'true',
        follow: process.env.NEXT_PUBLIC_IS_PRODUCTION == 'true',
    },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
    return (
        <html lang="en">
            <head>
                <script
                    type="application/ld+json"
                    dangerouslySetInnerHTML={{
                        __html: JSON.stringify({
                            '@context': 'https://schema.org',
                            '@type': 'Organization',
                            name: 'Blockchain',
                            url: process.env.NEXT_PUBLIC_APP_URL || '',
                            id: `${process.env.NEXT_PUBLIC_APP_URL}#organization`,
                            logo: `${process.env.NEXT_PUBLIC_APP_URL}/assets/images/logo.png`,
                            legalName: 'Blockchain',
                            sameAs: [process.env.NEXT_PUBLIC_APP_URL || ''],
                        }),
                    }}
                />
                <script
                    type="application/ld+json"
                    dangerouslySetInnerHTML={{
                        __html: JSON.stringify({
                            '@context': 'https://schema.org',
                            '@type': 'WebSite',
                            name: 'Blockchain',
                            url: process.env.NEXT_PUBLIC_APP_URL || '',
                            id: `${process.env.NEXT_PUBLIC_APP_URL}#website`,
                        }),
                    }}
                />
            </head>
            <body>
                <App />
                <div className="bg-black font-unbounded text-lg font-normal text-white antialiased">
                    <div className="relative h-full min-h-screen overflow-x-hidden bg-[url('/assets/images/background.png')] bg-cover bg-fixed bg-center">
                        <div className="main-bg fixed inset-0 h-screen w-screen object-cover opacity-5">
                            <Lottieplayer src="/assets/js/json/background.json" speed={1} className="h-full w-full" />
                        </div>
                        <Header />
                        <div className="h-full pt-20 md:pt-[109px]">
                            <Sidebar />
                            {children}
                        </div>
                    </div>
                </div>
            </body>
        </html>
    );
}
