const baseUrl = process.env.NEXT_PUBLIC_APP_URL || '';
const lastMod = new Date().toISOString();

async function generateSiteMap() {
    try {
        return `<?xml version="1.0" encoding="UTF-8"?>
        <urlset xmlns="https://www.sitemaps.org/schemas/sitemap/0.9">
        <url>
            <loc>${baseUrl}</loc>
            <lastmod>${lastMod}</lastmod>
        </url>
        <url>
            <loc>${baseUrl}/trade-risk</loc>
            <lastmod>${lastMod}</lastmod>
        </url>
        <url>
            <loc>${baseUrl}/claims</loc>
            <lastmod>${lastMod}</lastmod>
        </url>
        <url>
            <loc>${baseUrl}/privacy-policy</loc>
            <lastmod>${lastMod}</lastmod>
        </url>
        <url>
            <loc>${baseUrl}/about-us</loc>
            <lastmod>${lastMod}</lastmod>
        </url>
        <url>
            <loc>${baseUrl}/nft</loc>
            <lastmod>${lastMod}</lastmod>
        </url>
        </urlset>`;
    } catch (error) {}
}

export async function GET() {
    const body = await generateSiteMap();

    return new Response(body, {
        status: 200,
        headers: {
            'content-type': 'application/xml',
        },
    });
}
