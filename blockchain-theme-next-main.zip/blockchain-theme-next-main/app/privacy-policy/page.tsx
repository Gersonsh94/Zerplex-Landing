import helper from '@/libs/helper';
import type { Metadata } from 'next';

export const metadata: Metadata = {
    title: 'Privacy policy | Blockchain',
    description: 'Your privacy is important to us',
    openGraph: {
        ...helper.openGraphData,
        title: 'Privacy policy | Blockchain',
        description: 'Your privacy is important to us',
        url: process.env.NEXT_PUBLIC_APP_URL + '/privacy-policy',
        type: 'website',
    },
    twitter: {
        ...helper.twitterData,
        title: 'Privacy policy | Blockchain',
        description: 'Your privacy is important to us',
    },
    alternates: {
        canonical: `${process.env.NEXT_PUBLIC_APP_URL}/privacy-policy`,
        languages: { 'x-default': `${process.env.NEXT_PUBLIC_APP_URL}/privacy-policy` },
    },
};

const page = () => {
    return (
        <div className="relative z-1 w-full overflow-hidden pb-5 lg:pl-[300px] lg:pr-4">
            <div className="container">
                <div className="my-10 rounded-[50px] bg-white/10 py-14 px-4 md:my-14 md:px-10">
                    <h1 className="pb-10 text-center text-2xl font-medium md:text-3xl">Your privacy is important to us.</h1>
                    <div className="space-y-14">
                        <div className="space-y-6">
                            <h2 className="text-xl font-medium md:text-2xl">About</h2>
                            <div className="space-y-6 text-base! font-light tracking-widest opacity-50 md:text-lg">
                                <p>
                                    “Art” means any art, designs, drawings, traits, layers, and other design elements that may be associated with a Licensed NFT
                                    that you own.
                                </p>
                                <p>
                                    “Own” or “Ownership” means, with respect to a Licensed NFT, a Licensed NFT that you have purchased through the We bsite or
                                    otherwise rightfully acquired from a legitimate source, where proof of purchase was recorded on the applicable blockchain
                                    and ownership of the Licensed NFT can be proven.
                                </p>
                                <p>
                                    “NFT Trading Platform” means a secure marketplace where NFTs are sold, transferred, and recorded on the applicable
                                    blockchain and such transactions can be proven by the applicable blockchain.
                                </p>
                            </div>
                        </div>
                        <div className="space-y-6">
                            <h2 className="text-xl font-medium md:text-2xl">Legal information</h2>
                            <div className="space-y-6 text-base! font-light tracking-widest opacity-50 md:text-lg">
                                <p>
                                    This defense and indemnification obligation will survive this Agreement. You also agree that you have a duty to defend us
                                    against such claims and we may require you to pay for an attorney(s) of our choice in such cases. You agree that this
                                    indemnity extends to requiring you to pay for our reasonable attorneys’ fees, court costs, and disbursements. In the event
                                    of a claim such as one described in this paragraph, we may elect to settle with the party/parties making the claim and you
                                    shall be liable for the damages as though we had proceeded with a trial.
                                </p>
                                <p>All users who access the Site or buy Licensed NFTs must be 18 years of age or older.</p>
                            </div>
                        </div>
                        <div className="space-y-6">
                            <h2 className="text-xl font-medium md:text-2xl">Restriction to use</h2>
                            <div className="space-y-6 text-base! font-light tracking-widest opacity-50 md:text-lg">
                                <p>
                                    You further understand and agree that this license does not permit the ability to create any digital merchandise. The
                                    creation and minting of any new NFTs which are derivatives of your Licensed NFTs are expressly prohibited.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default page;
