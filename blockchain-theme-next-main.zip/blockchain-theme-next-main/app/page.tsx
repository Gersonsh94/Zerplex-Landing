import Lottieplayer from '@/components/Lottieplayer';
import Image from 'next/image';
import helper from '@/libs/helper';
import type { Metadata } from 'next';

export const metadata: Metadata = {
    title: 'Home | Blockchain',
    description: 'The cryptocurrency exchange of trust for individual and institutional traders & investors. An ethereum token backed by a human individual',
    openGraph: {
        ...helper.openGraphData,
        title: 'Home | Blockchain',
        description:
            'The cryptocurrency exchange of trust for individual and institutional traders & investors. An ethereum token backed by a human individual',
        url: process.env.NEXT_PUBLIC_APP_URL,
        type: 'website',
    },
    twitter: {
        ...helper.twitterData,
        title: 'Home | Blockchain',
        description:
            'The cryptocurrency exchange of trust for individual and institutional traders & investors. An ethereum token backed by a human individual',
    },
    alternates: {
        canonical: `${process.env.NEXT_PUBLIC_APP_URL}`,
        languages: { 'x-default': `${process.env.NEXT_PUBLIC_APP_URL}` },
    },
};

export default function Home() {
    return (
        <div className="relative z-1 w-full overflow-hidden pb-5 lg:pl-[300px] lg:pr-4">
            <div className="container">
                <div className="grid gap-5 xl:grid-cols-2">
                    <div className="relative pt-24 text-center lg:text-left">
                        <h1
                            className="mb-6 text-4xl font-semibold leading-tight sm:text-[52px]"
                            data-aos="zoom-in-right"
                            data-aos-duration="1000"
                            data-aos-delay="800"
                        >
                            <span className="inline-flex items-center gap-5">
                                <span className="shrink-0">Unlock the</span>
                                <div className="relative shrink-0 animate-pulse">
                                    <Image src="/assets/images/decentralized.png" alt="decentralized image" width={69} height={65} />
                                    <Image
                                        src="/assets/images/Vector1.png"
                                        alt="Vector1 image"
                                        className="absolute right-8 bottom-10 min-w-[150px]"
                                        width={150}
                                        height={94}
                                    />
                                </div>
                            </span>
                            decentralized
                            <span className="animate-text mx-auto block bg-linear-to-r from-[#9A42FE] to-[#23EF9B] bg-clip-text text-transparent lg:mx-0">
                                future.
                            </span>
                        </h1>
                        <p className="font-light leading-7 opacity-40 2xl:pr-24">
                            The cryptocurrency exchange of trust for individual and institutional traders & investors. An ethereum token backed by a human
                            individual
                        </p>
                        <div
                            className="mx-auto mt-10 flex w-full max-w-xl items-center gap-3 border-y-2 border-white/10 py-7 sm:mt-16 lg:mx-0"
                            data-aos="zoom-out"
                            data-aos-duration="1000"
                            data-aos-delay="800"
                        >
                            <h2 className="shrink-0 animate-pulse text-2xl font-semibold text-primary sm:text-5xl">3.8 M+</h2>
                            <span className="block h-[3px] w-full rounded-full bg-linear-to-r from-primary via-tertiary to-secondary"></span>
                            <h2 className="shrink-0 animate-pulse text-base font-medium sm:text-xl">Market network</h2>
                        </div>
                    </div>
                    <div className="hero-banner flex items-center justify-center 2xl:ml-16">
                        <Lottieplayer src="/assets/js/json/main-banner.json" className="w-full h-full hero-banner xl:max-w-full xl:w-144" speed={0.4} />
                    </div>
                </div>
                <div className="relative py-6">
                    <div className="cloak-img relative w-32 sm:w-48">
                        <Image src="/assets/images/cloak.png" alt="cloak image" width={192} height={198} />
                    </div>
                    <div className="relative z-1 -mt-4 overflow-x-hidden bg-primary p-4">
                        <ul className="flex animate-marquee gap-4 whitespace-nowrap text-sm font-medium text-black sm:text-xl">
                            <li>Trade Tokens</li>•<li>Mint NFTs</li>•<li>Game On-Chain</li>✦<li>Trade Tokens</li>•<li>Mint NFTs</li>•<li>Game On-Chain</li>✦
                            <li>Trade Tokens</li>•<li>Mint NFTs</li>•<li>Game On-Chain</li>✦<li>Trade Tokens</li>•<li>Mint NFTs</li>•<li>Game On-Chain</li>✦
                            <li>Trade Tokens</li>•<li>Mint NFTs</li>•<li>Game On-Chain</li>✦<li>Trade Tokens</li>•<li>Mint NFTs</li>•<li>Game On-Chain</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    );
}
