import IconUpLeftArrow from '@/components/Icons/IconUpLeftArrow';
import IconDoubleQuotes from '@/components/Icons/IconDoubleQuotes';
import IconLongDownArrow from '@/components/Icons/IconLongDownArrow';
import AboutUsModal from '@/components/AboutUsModal';
import Image from 'next/image';
import helper from '@/libs/helper';
import type { Metadata } from 'next';

export const metadata: Metadata = {
    title: 'About us | Blockchain',
    description: 'Global decentralized currency based on blockchain technology',
    openGraph: {
        ...helper.openGraphData,
        title: 'About us | Blockchain',
        description: 'Global decentralized currency based on blockchain technology',
        url: process.env.NEXT_PUBLIC_APP_URL + '/about-us',
        type: 'website',
    },
    twitter: {
        ...helper.twitterData,
        title: 'About us | Blockchain',
        description: 'Global decentralized currency based on blockchain technology',
    },
    alternates: {
        canonical: `${process.env.NEXT_PUBLIC_APP_URL}/about-us`,
        languages: { 'x-default': `${process.env.NEXT_PUBLIC_APP_URL}/about-us` },
    },
};

const page = () => {
    return (
        <div className="w-full overflow-hidden pb-5 lg:pl-[300px] lg:pr-4">
            <div className="container">
                <div>
                    <div className="space-y-8 py-12 text-center md:py-16">
                        <h1
                            className="animate-text text-gradiant mx-auto text-2xl font-medium md:text-[28px] md:leading-9 xl:max-w-2xl"
                            data-aos="zoom-in"
                            data-aos-duration="1000"
                            data-aos-delay="800"
                        >
                            Global decentralized currency based on blockchain technology
                        </h1>
                        <p className="opacity-50">Crypterium blockchain is most popular way to buy and sell cryptocurrency & NFTS.</p>
                    </div>
                    <div className="grid gap-5 text-center sm:grid-cols-2 md:grid-cols-3 xl:gap-12">
                        <div data-aos="zoom-in" data-aos-duration="1500" data-aos-delay="800">
                            <div className="bg-linear-to-b from-tertiary via-transparent to-transparent p-[2.5px] duration-300 hover:scale-105">
                                <div className="h-full space-y-6 bg-black px-5 pt-6 pb-11">
                                    <div className="token">
                                        <Image
                                            src="/assets/images/access-token-creation.svg"
                                            alt="access-token-creation"
                                            className="mx-auto"
                                            width={86}
                                            height={86}
                                        />
                                    </div>
                                    <h2>Access token creation</h2>
                                    <p className="text-sm opacity-50">
                                        Scale with data accuracy- our system mitigates common issues from running multiple nodes.
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div data-aos="zoom-in" data-aos-duration="1500" data-aos-delay="800">
                            <div className="bg-linear-to-b from-transparent via-transparent to-secondary p-[2.5px] duration-300 hover:scale-105">
                                <div className="h-full space-y-6 bg-black px-5 pt-6 pb-11">
                                    <div className="token">
                                        <Image
                                            src="/assets/images/ownership-token-control.svg"
                                            alt="ownership-token-control"
                                            className="mx-auto"
                                            width={86}
                                            height={86}
                                        />
                                    </div>
                                    <h2>Ownership token control</h2>
                                    <p className="text-sm opacity-50">A suite of API methods to make transaction tracing debugging easy and insightful.</p>
                                </div>
                            </div>
                        </div>
                        <div data-aos="zoom-in" data-aos-duration="1500" data-aos-delay="800">
                            <div className="bg-linear-to-b from-primary via-transparent to-transparent p-[2.5px] duration-300 hover:scale-105">
                                <div className="h-full space-y-6 bg-black px-5 pt-6 pb-11">
                                    <div className="token">
                                        <Image
                                            src="/assets/images/assign-opfc-metadata.svg"
                                            alt="assign-opfc-metadata"
                                            className="mx-auto"
                                            width={86}
                                            height={86}
                                        />
                                    </div>
                                    <h2>Assign OPFS metadata</h2>
                                    <p className="text-sm opacity-50">
                                        A growing list of API methods to get more, like tokens or transaction insight in less requests.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="relative mx-auto mt-14 grid max-w-[1200px] grid-cols-3 gap-8 md:mt-24 xl:block xl:pt-[500px]">
                        <div className="absolute left-1/2 bottom-10 hidden -translate-x-1/2 xl:block">
                            <svg width="793" height="369" viewBox="0 0 793 369" fill="none">
                                <path
                                    d="M7.99805 270.948H82.1827C89.0765 270.948 95.6151 274.006 100.034 279.297L162.047 353.548C166.466 358.839 173.004 361.898 179.898 361.898H255.116"
                                    stroke="transparent"
                                    strokeWidth="14"
                                    strokeLinecap="round"
                                ></path>
                                <path
                                    d="M786 270.948H711.815C704.922 270.948 698.383 274.006 693.964 279.297L631.951 353.548C627.532 358.839 620.994 361.898 614.1 361.898H538.882"
                                    stroke="transparent"
                                    strokeWidth="14"
                                    strokeLinecap="round"
                                ></path>
                                <path
                                    d="M660.944 74.5036L615.837 186.058C611.288 197.306 600.369 204.669 588.237 204.669H542.678"
                                    stroke="transparent"
                                    strokeWidth="14"
                                    strokeLinecap="round"
                                ></path>
                                <path
                                    d="M130.677 74.5036L175.784 186.058C180.333 197.306 191.252 204.669 203.384 204.669H248.943"
                                    stroke="transparent"
                                    strokeWidth="14"
                                    strokeLinecap="round"
                                ></path>
                                <path d="M397 7.71542L397 82.1922L397 119.431L397 156.669" stroke="transparent" strokeWidth="14" strokeLinecap="round"></path>
                                <path
                                    className="dott-line-animation"
                                    d="M7.99805 270.948H82.1827C89.0765 270.948 95.6151 274.006 100.034 279.297L162.047 353.548C166.466 358.839 173.004 361.898 179.898 361.898H255.116"
                                    stroke="#28A0F0"
                                    strokeWidth="2.79102"
                                    strokeLinecap="round"
                                    strokeDasharray="18.61 18.61"
                                ></path>
                                <path
                                    className="dott-line-animation"
                                    d="M786 270.948H711.815C704.922 270.948 698.383 274.006 693.964 279.297L631.951 353.548C627.532 358.839 620.994 361.898 614.1 361.898H538.882"
                                    stroke="#F79009"
                                    strokeWidth="2.79102"
                                    strokeLinecap="round"
                                    strokeDasharray="18.61 18.61"
                                ></path>
                                <path
                                    className="dott-line-animation"
                                    d="M660.944 74.5036L615.837 186.058C611.288 197.306 600.369 204.669 588.237 204.669H542.678"
                                    stroke="#F23535"
                                    strokeWidth="2.79102"
                                    strokeLinecap="round"
                                    strokeDasharray="18.61 18.61"
                                ></path>
                                <path
                                    className="dott-line-animation"
                                    d="M130.677 74.5036L175.784 186.058C180.333 197.306 191.252 204.669 203.384 204.669H248.943"
                                    stroke="#7F56D9"
                                    strokeWidth="2.79102"
                                    strokeLinecap="round"
                                    strokeDasharray="18.61 18.61"
                                ></path>
                                <path
                                    className="dott-line-animation"
                                    d="M397 7.71542L397 82.1922L397 119.431L397 156.669"
                                    stroke="#2074F1"
                                    strokeWidth="2.79102"
                                    strokeLinecap="round"
                                    strokeDasharray="22.33 22.33"
                                ></path>
                            </svg>
                        </div>
                        <AboutUsModal />
                        <div className="left-12 bottom-16 xl:absolute">
                            <Image src="/assets/images/currency-1.png" alt="/currency-1" className="mx-auto" width={160} height={160} />
                        </div>
                        <div className="left-48 top-16 xl:absolute 2xl:left-52">
                            <Image src="/assets/images/currency-2.png" alt="/currency-2" className="mx-auto" width={160} height={160} />
                        </div>
                        <div className="top-0 left-2/4 xl:absolute xl:-translate-x-1/2">
                            <Image src="/assets/images/currency-3.png" alt="/currency-3" className="mx-auto" width={160} height={160} />
                        </div>
                        <div className="right-48 top-16 xl:absolute 2xl:right-52">
                            <Image src="/assets/images/currency-4.png" alt="/currency-4" className="mx-auto" width={160} height={160} />
                        </div>
                        <div className="right-12 bottom-16 xl:absolute">
                            <Image src="/assets/images/currency-5.png" alt="/currency-5" className="mx-auto" width={160} height={160} />
                        </div>
                    </div>
                </div>

                <div className="py-14 md:py-24">
                    <div className="space-y-8 pb-12 text-center md:py-16">
                        <h2
                            className="animate-text text-gradiant mx-auto inline-block text-2xl font-medium md:text-[28px] md:leading-9"
                            data-aos="zoom-in"
                            data-aos-duration="1000"
                        >
                            Built-in Security - Full multi-chain support
                        </h2>
                        <p className="opacity-50">Secure your application by preventing unauthorized access & universal accessibility.</p>
                    </div>
                    <div className="relative mx-auto xl:w-4/5">
                        <Image src="/assets/images/multi-chain.png" alt="multi-chain" className="w-full" width={1188} height={359} />
                        <Image
                            src="/assets/images/diamond-3d.gif"
                            alt="diamond-3d"
                            className="absolute top-1/2 right-[5%] w-[12%] -translate-y-1/2"
                            width={143}
                            height={143}
                        />
                    </div>
                </div>

                <div className="relative mb-5 rounded-[50px] bg-white/10 px-5 py-10 md:p-14 md:pb-20">
                    <span className="absolute right-24 -top-14 animate-spin-slow">
                        <Image src="/assets/images/star.svg" alt="star" width={146} height={146} />
                    </span>
                    <div className="mb-14 2xl:w-2/3">
                        <div className="flex gap-6">
                            <h2 className="text-2xl font-semibold md:text-40" data-aos="zoom-in" data-aos-duration="1000">
                                Let’s make something incredible together!
                            </h2>
                            <div className="group relative hidden h-28 w-28 shrink-0 items-center justify-center rounded-full border border-[#9E9E9E] p-1 text-[#9E9E9E] duration-300 hover:border-primary hover:text-primary xl:-mt-6 xl:inline-flex">
                                <Image
                                    src="/assets/images/your-creative-partner-txt.png"
                                    alt="your-creative-partner-txt"
                                    className="animate-spin-slow"
                                    width={102}
                                    height={102}
                                />
                                <span className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 duration-300 group-hover:scale-90">
                                    <IconUpLeftArrow />
                                </span>
                            </div>
                        </div>
                        <p className="mt-6 leading-6 opacity-50">
                            you have come across the right choice! our plan is the best monthly solution to all product needs.
                        </p>
                    </div>
                    <div className="border-white/20 md:flex md:border-y-[3px] xl:w-[95%]">
                        <div className="flex items-center justify-center md:w-1/3 md:justify-end">
                            <Image
                                src="/assets/images/invitation-email.svg"
                                alt="invitation-email"
                                data-aos="fade-right"
                                data-aos-duration="2000"
                                width={315}
                                height={196}
                            />
                        </div>
                        <form className="relative border-white/20 py-6 md:w-2/3 md:border-l-[3px] md:pl-9 xl:pb-20">
                            <div className="space-y-6">
                                <div>
                                    <input
                                        type="text"
                                        placeholder="Full name"
                                        className="w-full border-b-[3px] border-white/20 bg-transparent py-4 outline-hidden placeholder:text-white xl:pr-24"
                                    />
                                </div>
                                <div>
                                    <input
                                        type="email"
                                        placeholder="Email address"
                                        className="w-full border-b-[3px] border-white/20 bg-transparent py-4 outline-hidden placeholder:text-white xl:pr-24"
                                    />
                                </div>
                                <div>
                                    <input
                                        type="text"
                                        placeholder="Company name"
                                        className="w-full border-b-[3px] border-white/20 bg-transparent py-4 outline-hidden placeholder:text-white xl:pr-24"
                                    />
                                </div>
                            </div>
                            <div
                                className="-right-12 -bottom-1 mt-5 flex flex-col items-center justify-between rounded-full bg-linear-to-b from-secondary to-primary xl:absolute xl:mt-0 xl:p-2.5 xl:pt-8"
                                data-aos="fade-down"
                                data-aos-duration="1000"
                            >
                                <span className="mb-8 hidden xl:block">
                                    <IconDoubleQuotes />
                                </span>
                                <span className="hidden animate-bounce xl:block">
                                    <IconLongDownArrow />
                                </span>
                                <button
                                    type="button"
                                    className="relative w-full overflow-hidden rounded-t-full rounded-b-full border-2 border-black p-4 text-xl font-semibold text-black duration-300 before:absolute before:inset-x-0 before:-bottom-full before:z-[-1] before:h-full before:w-full before:bg-black before:duration-300 hover:text-white hover:before:bottom-0 xl:mt-5 xl:py-16"
                                >
                                    Send
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default page;
