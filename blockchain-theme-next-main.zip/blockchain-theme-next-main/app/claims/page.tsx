import CountsUp from '@/components/CountsUp';
import IconDownRightArrow from '@/components/Icons/IconDownRightArrow';
import IconProcessArrow from '@/components/Icons/IconProcessArrow';
import IconUpLeftArrow from '@/components/Icons/IconUpLeftArrow';
import Image from 'next/image';
import helper from '@/libs/helper';
import type { Metadata } from 'next';

export const metadata: Metadata = {
    title: 'Claims | Blockchain',
    description: 'Well-planned to trade in crypto.',
    openGraph: {
        ...helper.openGraphData,
        title: 'Claims | Blockchain',
        description: 'Well-planned to trade in crypto.',
        url: process.env.NEXT_PUBLIC_APP_URL + '/claims',
        type: 'website',
    },
    twitter: {
        ...helper.twitterData,
        title: 'Claims | Blockchain',
        description: 'Well-planned to trade in crypto.',
    },
    alternates: {
        canonical: `${process.env.NEXT_PUBLIC_APP_URL}/claims`,
        languages: { 'x-default': `${process.env.NEXT_PUBLIC_APP_URL}/claims` },
    },
};

const page = () => {
    return (
        <div className="relative z-1 w-full overflow-hidden pb-5 lg:pl-[300px] lg:pr-4">
            <div className="container">
                <div className="items-start py-14 xl:flex xl:py-24">
                    <div className="flex flex-col pb-10 xl:w-2/5 xl:pb-0">
                        <div className="relative order-2 overflow-hidden rounded-[50px] bg-white/10 px-4 pb-20 pt-5 text-center xl:order-1 xl:rounded-r-none xl:pt-20 xl:pb-60">
                            <span>
                                <Image src="/assets/images/process-design.svg" alt="process-design" className="ml-auto" width={151} height={62} />
                            </span>
                            <div className="relative inline-block" data-aos="fade-up" data-aos-duration="1000" data-aos-delay="800">
                                <h1 className="animate-text text-gradiant text-3xl font-semibold leading-tight md:text-[40px]">How to process?</h1>
                                <span className="absolute left-16 -top-8 animate-spin-slow">
                                    <Image src="/assets/images/star.svg" alt="star" width={146} height={146} />
                                </span>
                                <span className="absolute -left-7 top-0">
                                    <Image src="/assets/images/plus-vector.svg" alt="plus-vector" width={47} height={54} />
                                </span>
                            </div>
                            <div className="absolute top-0 left-1/2 flex -translate-x-1/2 gap-4">
                                <div className="bar bar1"></div>
                                <div className="bar bar2"></div>
                                <div className="bar bar3"></div>
                                <div className="bar bar4"></div>
                                <div className="bar bar1"></div>
                                <div className="bar bar5"></div>
                                <div className="bar bar6"></div>
                            </div>
                        </div>
                        <div className="order-1 pb-10 text-center xl:order-2 xl:pb-0 xl:pt-10 xl:pr-10 xl:text-left">
                            <h2 className="relative text-4xl font-semibold leading-tight md:text-[52px]">
                                <span className="animate-text bg-linear-to-r from-secondary to-primary bg-clip-text text-transparent">Well-planned </span>
                                to trade in crypto.
                                <span
                                    className="absolute left-6 bottom-0 hidden animate-pulse lg:block xl:-bottom-16"
                                    data-aos="fade-up"
                                    data-aos-duration="2000"
                                    data-aos-delay="800"
                                >
                                    <Image src="/assets/images/two-line-svg.png" alt="two-line-svg" width={47} height={160} />
                                </span>
                            </h2>
                        </div>
                    </div>
                    <div className="rounded-[50px] bg-white/10 p-4 sm:p-7 xl:w-3/5 xl:rounded-tl-none">
                        <div className="space-y-14 rounded-[50px] border-[3px] border-white/10 px-4 py-10 sm:px-6">
                            <div className="text-center sm:text-left">
                                <div className="items-end gap-6 pb-6 font-semibold sm:inline-flex">
                                    <span className="text-[32px]">01</span>
                                    <span className="hidden sm:block">
                                        <IconProcessArrow className="process-arrow" />
                                    </span>
                                    <h3 className="my-5 text-[22px] sm:my-0">Trading chain</h3>
                                    <div className="process-icon sm:-mb-5">
                                        <Image src="/assets/images/trading-chain.png" alt="trading-chain" className="mx-auto sm:mx-0" width={72} height={108} />
                                    </div>
                                </div>
                                <p className="text-base leading-5 opacity-50">
                                    The act of speculating on cryptocurrency price movements via a CFD trading account, or buying and selling. Accept and
                                    process payments from all types of currencies.
                                </p>
                            </div>
                            <div className="text-center sm:text-left">
                                <div className="items-end gap-6 pb-6 font-semibold sm:inline-flex">
                                    <span className="text-[32px]">02</span>
                                    <span className="hidden sm:block">
                                        <IconProcessArrow className="process-arrow" />
                                    </span>
                                    <h3 className="my-5 text-[22px] sm:my-0">Buying bits</h3>
                                    <div className="process-icon sm:-mb-5">
                                        <Image src="/assets/images/buying-bits.png" alt="buying-bits" className="mx-auto sm:mx-0" width={85} height={105} />
                                    </div>
                                </div>
                                <p className="text-base leading-5 opacity-50">
                                    Best cryptocurrency exchanges currently purchase Bitcoin, Ethereum, and Lite coin other coins and tokens on the platform.
                                    Build NFT apps on popular L1 and L2 chains including Ethereum, Polygon, Optimism, and Arbitrum.
                                </p>
                            </div>
                            <div className="text-center sm:text-left">
                                <div className="items-end gap-6 pb-6 font-semibold sm:inline-flex">
                                    <span className="text-[32px]">03</span>
                                    <span className="hidden sm:block">
                                        <IconProcessArrow className="process-arrow" />
                                    </span>
                                    <h3 className="my-5 text-[22px] sm:my-0">Block chain system</h3>
                                    <div className="process-icon sm:-mb-5">
                                        <Image
                                            src="/assets/images/block-chain-system.png"
                                            alt="block-chain-system"
                                            className="mx-auto sm:mx-0"
                                            width={74}
                                            height={108}
                                        />
                                    </div>
                                </div>
                                <p className="text-base leading-5 opacity-50">
                                    How it Works, benefits and its deployment in financial, create unique crypto cards and why cryptocurrency are the future.
                                    Easily identify ownership so you can grant access to rewards, communities, benefits, and websites.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="relative rounded-[50px] bg-white/10 py-14 px-4 md:px-10">
                    <Image
                        src="/assets/images/drawing-pencil.png"
                        alt="drawing-pencil"
                        className="absolute top-1/2 left-12 hidden -translate-y-1/2 xl:block"
                        width={332}
                        height={286}
                    />
                    <div className="ml-auto text-center xl:w-11/12 xl:text-right 2xl:w-4/5">
                        <div className="ml-auto mb-14 2xl:w-3/5">
                            <div className="flex">
                                <div className="group relative hidden h-28 w-28 shrink-0 items-center justify-center rounded-full border border-[#9E9E9E] p-1 text-[#9E9E9E] duration-300 hover:border-primary hover:text-primary xl:-mt-6 xl:inline-flex">
                                    <Image
                                        src="/assets/images/your-creative-partner-txt.png"
                                        alt="your-creative-partner-txt"
                                        className="animate-spin-slow"
                                        width={102}
                                        height={102}
                                    />
                                    <span className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 duration-300 group-hover:scale-90">
                                        <IconUpLeftArrow />
                                    </span>
                                </div>
                                <h2 className="text-3xl font-semibold md:text-40">Let’s make something incredible together!</h2>
                            </div>
                            <p className="mt-6 leading-6 opacity-50">
                                you have come across the right choice! our plan is the best monthly solution to all product needs.
                            </p>
                        </div>
                        <div className="grid justify-center gap-10 uppercase sm:grid-cols-2 md:grid-cols-3 md:justify-between">
                            <div className="flex flex-col gap-3" data-aos="zoom-in" data-aos-duration="1000">
                                <span className="text-40 font-bold text-primary">
                                    <CountsUp start={0} end={10} duration={4} delay={1} suffix="" />
                                </span>
                                <span>YEARS EXPERIENCE</span>
                            </div>
                            <div className="flex flex-col gap-3" data-aos="zoom-in" data-aos-duration="1500">
                                <span className="text-40 font-bold text-primary">
                                    {' '}
                                    <CountsUp start={0} end={1} duration={1} delay={1} suffix="M +" />
                                </span>
                                <span>ACTIVE USERS</span>
                            </div>
                            <div className="flex flex-col gap-3" data-aos="zoom-in" data-aos-duration="2000">
                                <span className="text-40 font-bold text-primary">
                                    {' '}
                                    <CountsUp start={0} end={60} duration={4} delay={1} suffix=" +" />
                                </span>
                                <span>WALLET SUPPORTED</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="divide-y-[3px] divide-white/20 pt-12">
                    <div
                        className="grid-cols-9 items-center justify-between gap-10 py-12 text-center lg:grid lg:text-left"
                        data-aos="fade-up"
                        data-aos-duration="1000"
                    >
                        <div className="col-span-3">
                            <span className="process-icon bg-linear-to-b from-white/20 to-transparent bg-clip-text text-6xl font-extrabold text-transparent">
                                01
                            </span>
                            <h2 className="text-2xl font-semibold lg:-mt-6 xl:text-4xl 2xl:text-40">
                                Understanding brief<span className="text-tertiary">.</span>
                            </h2>
                        </div>
                        <div className="col-span-4 py-8 leading-6 opacity-50">
                            <p>
                                The first process is to understand the brief that has been sent by the client via online meet or chat and then the next process
                                is the deal budget.
                            </p>
                        </div>
                        <div className="col-span-2 shrink-0 text-center lg:text-right">
                            <a
                                href="#"
                                className="group relative inline-flex h-20 w-20 items-center justify-center overflow-hidden rounded-full border-4 border-[#353435] bg-transparent duration-300 hover:border-primary hover:bg-primary"
                            >
                                <span className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-[#353435] transition-all duration-300 group-hover:top-20 group-hover:left-20">
                                    <IconDownRightArrow className="transition-all duration-500" />
                                </span>
                                <span className="absolute -top-10 -left-10 text-black transition-all duration-300 group-hover:top-1/2 group-hover:left-1/2 group-hover:-translate-x-1/2 group-hover:-translate-y-1/2">
                                    <IconDownRightArrow className="transition-all duration-500" />
                                </span>
                            </a>
                        </div>
                    </div>
                    <div
                        className="grid-cols-9 items-center justify-between gap-10 py-12 text-center lg:grid lg:text-left"
                        data-aos="fade-up"
                        data-aos-duration="1000"
                    >
                        <div className="col-span-3">
                            <span className="process-icon bg-linear-to-b from-white/20 to-transparent bg-clip-text text-6xl font-extrabold text-transparent">
                                02
                            </span>
                            <h2 className="text-2xl font-semibold lg:-mt-6 xl:text-4xl 2xl:text-40">
                                Multi-chain support<span className="text-secondary">.</span>
                            </h2>
                        </div>
                        <div className="col-span-4 py-8 leading-6 opacity-50">
                            <p>Build NFT apps on popular L1 and L2 chains including Ethereum, Polygon, Optimism, and Arbitrum.</p>
                        </div>
                        <div className="col-span-2 shrink-0 text-center lg:text-right">
                            <a
                                href="#"
                                className="group relative inline-flex h-20 w-20 items-center justify-center overflow-hidden rounded-full border-4 border-[#353435] bg-transparent duration-300 hover:border-primary hover:bg-primary"
                            >
                                <span className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-[#353435] transition-all duration-300 group-hover:top-20 group-hover:left-20">
                                    <IconDownRightArrow className="transition-all duration-500" />
                                </span>
                                <span className="absolute -top-10 -left-10 text-black transition-all duration-300 group-hover:top-1/2 group-hover:left-1/2 group-hover:-translate-x-1/2 group-hover:-translate-y-1/2">
                                    <IconDownRightArrow className="transition-all duration-500" />
                                </span>
                            </a>
                        </div>
                    </div>
                    <div
                        className="grid-cols-9 items-center justify-between gap-10 py-12 text-center lg:grid lg:text-left"
                        data-aos="fade-up"
                        data-aos-duration="1000"
                    >
                        <div className="col-span-3">
                            <span className="process-icon bg-linear-to-b from-white/20 to-transparent bg-clip-text text-6xl font-extrabold text-transparent">
                                03
                            </span>
                            <h2 className="text-2xl font-semibold lg:-mt-6 xl:text-4xl 2xl:text-40">
                                More data more power<span className="text-tertiary">.</span>
                            </h2>
                        </div>
                        <div className="col-span-4 py-8 leading-6 opacity-50">
                            <p>Bigger is better and with 3x more NFT data than others build more powerful</p>
                        </div>
                        <div className="col-span-2 shrink-0 text-center lg:text-right">
                            <a
                                href="#"
                                className="group relative inline-flex h-20 w-20 items-center justify-center overflow-hidden rounded-full border-4 border-[#353435] bg-transparent duration-300 hover:border-primary hover:bg-primary"
                            >
                                <span className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-[#353435] transition-all duration-300 group-hover:top-20 group-hover:left-20">
                                    <IconDownRightArrow className="transition-all duration-500" />
                                </span>
                                <span className="absolute -top-10 -left-10 text-black transition-all duration-300 group-hover:top-1/2 group-hover:left-1/2 group-hover:-translate-x-1/2 group-hover:-translate-y-1/2">
                                    <IconDownRightArrow className="transition-all duration-500" />
                                </span>
                            </a>
                        </div>
                    </div>
                    <div
                        className="grid-cols-9 items-center justify-between gap-10 py-12 text-center lg:grid lg:text-left"
                        data-aos="fade-up"
                        data-aos-duration="1000"
                    >
                        <div className="col-span-3">
                            <span className="process-icon bg-linear-to-b from-white/20 to-transparent bg-clip-text text-6xl font-extrabold text-transparent">
                                04
                            </span>
                            <h2 className="text-2xl font-semibold lg:-mt-6 xl:text-4xl 2xl:text-40">
                                Verified NFTs & spam detection<span className="text-secondary">.</span>
                            </h2>
                        </div>
                        <div className="col-span-4 py-8 leading-6 opacity-50">
                            <p>Identify trusted NFTs so you know they originated from the creator and filter out spam and unwanted NFTs.</p>
                        </div>
                        <div className="col-span-2 shrink-0 text-center lg:text-right">
                            <a
                                href="#"
                                className="group relative inline-flex h-20 w-20 items-center justify-center overflow-hidden rounded-full border-4 border-[#353435] bg-transparent duration-300 hover:border-primary hover:bg-primary"
                            >
                                <span className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-[#353435] transition-all duration-300 group-hover:top-20 group-hover:left-20">
                                    <IconDownRightArrow className="transition-all duration-500" />
                                </span>
                                <span className="absolute -top-10 -left-10 text-black transition-all duration-300 group-hover:top-1/2 group-hover:left-1/2 group-hover:-translate-x-1/2 group-hover:-translate-y-1/2">
                                    <IconDownRightArrow className="transition-all duration-500" />
                                </span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default page;
