import IconETHE from '@/components/Icons/IconETHE';
import IconUSDT from '@/components/Icons/IconUSDT';
import Lottieplayer from '@/components/Lottieplayer';
import Image from 'next/image';
import helper from '@/libs/helper';
import type { Metadata } from 'next';

export const metadata: Metadata = {
    title: 'Trade risk | Blockchain',
    description: 'Cross Chain Blockchain network for metaverse',
    openGraph: {
        ...helper.openGraphData,
        title: 'Trade risk | Blockchain',
        description: 'Cross Chain Blockchain network for metaverse',
        url: process.env.NEXT_PUBLIC_APP_URL + '/trade-risk',
        type: 'website',
    },
    twitter: {
        ...helper.twitterData,
        title: 'Trade risk | Blockchain',
        description: 'Cross Chain Blockchain network for metaverse',
    },
    alternates: {
        canonical: `${process.env.NEXT_PUBLIC_APP_URL}/trade-risk`,
        languages: { 'x-default': `${process.env.NEXT_PUBLIC_APP_URL}/trade-risk` },
    },
};

const page = () => {
    return (
        <div className="relative z-1 w-full overflow-hidden pb-5 lg:pl-[300px] lg:pr-4">
            <div className="container">
                <div className="grid gap-10 xl:grid-cols-2">
                    <div className="pt-12 lg:pt-24">
                        <div className="text-center xl:text-left">
                            <h1
                                className="mb-6 text-4xl font-semibold leading-tight! md:text-5xl"
                                data-aos="zoom-in-right"
                                data-aos-duration="1000"
                                data-aos-delay="800"
                            >
                                <span className="animate-text bg-linear-to-r from-[#9A42FE] to-[#23EF9B] bg-clip-text text-transparent">Cross • Chain </span>
                                Blockchain network for metaverse
                            </h1>
                            <p className="font-light leading-7 opacity-40">
                                We do not charge any fees and we do not require any registration. You keep your privacy and your coins.
                            </p>
                        </div>
                        <div className="space-y-7 pt-10 lg:pt-20 2xl:pt-56">
                            <div className="relative flex flex-col items-center justify-between gap-4 bg-tertiary/20 py-8 px-5 ring-2 ring-inset ring-tertiary sm:flex-row sm:py-4 2xl:w-4/5">
                                <div className="flex flex-col items-center space-y-0.5 sm:items-start">
                                    <span className="text-2xl font-semibold">50</span>
                                    <span className="text-base font-medium opacity-50">$ 131,362</span>
                                </div>
                                <button type="button" className="flex items-center gap-3.5 bg-tertiary py-2 px-4 duration-300 hover:bg-opacity-50">
                                    <span className="shrink-0">
                                        <IconETHE />
                                    </span>
                                    <span className="text-xl font-medium">ETHE</span>
                                </button>
                                <button
                                    type="button"
                                    className="group absolute -bottom-11 left-1/2 flex h-16 w-16 -translate-x-1/2 items-center justify-center rounded-full bg-primary duration-500 hover:bg-white"
                                >
                                    <Image
                                        src="/assets/images/transfer.svg"
                                        alt="transfer"
                                        className="duration-500 group-hover:rotate-180"
                                        width={36}
                                        height={36}
                                    />
                                </button>
                            </div>
                            <div className="flex flex-col items-center justify-between gap-4 bg-secondary/20 py-8 px-5 ring-2 ring-inset ring-secondary sm:flex-row sm:py-4 2xl:w-4/5">
                                <div className="flex flex-col items-center space-y-0.5 sm:items-start">
                                    <span className="text-2xl font-semibold">131742</span>
                                    <span className="text-base font-medium opacity-50">$ 132,048</span>
                                </div>
                                <button type="button" className="flex items-center gap-3.5 bg-secondary py-2 px-4 duration-300 hover:bg-opacity-50">
                                    <span className="shrink-0">
                                        <IconUSDT />
                                    </span>
                                    <span className="text-xl font-medium">USDT</span>
                                </button>
                            </div>
                            <p className="text-base opacity-50">
                                <span>1 USDT</span> = <span>0.00003796 ETH</span>
                            </p>
                        </div>
                    </div>
                    <div className="relative space-y-10 sm:space-y-0 xl:pt-20 2xl:pl-16">
                        <div className="grid items-center justify-items-center gap-4 sm:grid-cols-2 sm:gap-0">
                            <div
                                className="border-2 border-white/50"
                                style={{
                                    background: `linear-gradient(
                            180deg,
                            rgba(255, 255, 255, 0.2) 0%,
                            rgba(255, 255, 255, 0) 13.02%,
                            rgba(255, 255, 255, 0) 54.17%,
                            rgba(255, 255, 255, 0) 88.54%,
                            rgba(255, 255, 255, 0.2) 100%
                        )`,
                                }}
                            >
                                <Lottieplayer src="/assets/js/json/minting-process.json" speed={1} className="h-full w-full" loop autoplay></Lottieplayer>
                            </div>
                            <div data-aos="zoom-in-left" data-aos-duration="1000" data-aos-delay="800">
                                <button type="button" className="bg-linear-to-r from-primary to-secondary py-2 px-4 text-xl text-white transition-all">
                                    Minting process
                                </button>
                            </div>
                        </div>
                        <div className="relative z-1 grid items-center justify-items-center gap-4 sm:grid-cols-2 sm:gap-0">
                            <div className="order-2 sm:order-1" data-aos="zoom-in-right" data-aos-duration="1000" data-aos-delay="800">
                                <button type="button" className="bg-linear-to-r from-secondary to-primary py-2 px-4 text-xl text-white">
                                    Trade token
                                </button>
                            </div>

                            <div
                                className="order-1 border-2 border-white/50 sm:order-2"
                                style={{
                                    background: `linear-gradient(
                            180deg,
                            rgba(255, 255, 255, 0.2) 0%,
                            rgba(255, 255, 255, 0) 13.02%,
                            rgba(255, 255, 255, 0) 54.17%,
                            rgba(255, 255, 255, 0) 88.54%,
                            rgba(255, 255, 255, 0.2) 100%
                        )`,
                                }}
                            >
                                <Lottieplayer src="/assets/js/json/trade-token.json" speed={1} loop autoplay className="w-full"></Lottieplayer>
                            </div>
                        </div>
                        <Image
                            src="/assets/images/location-bg.svg"
                            alt="location-bg"
                            className="absolute left-0 bottom-0 xl:-left-20"
                            width={396}
                            height={271}
                        />
                    </div>
                </div>
                <div className="pt-16 lg:pt-24">
                    <div className="text-center" data-aos="zoom-in" data-aos-duration="1000">
                        <h2 className="text-4xl font-semibold md:text-5xl">
                            Powerful{' '}
                            <span className="animate-text bg-linear-to-r from-[#9A42FE] to-[#23EF9B] bg-clip-text text-transparent">Defi feature</span>
                        </h2>
                    </div>
                    <div className="grid gap-10 pt-12 text-base md:grid-cols-2 xl:gap-16">
                        <div className="overflow-hidden border-2 border-tertiary bg-tertiary/5 p-6 pb-8">
                            <div className="space-y-4">
                                <div data-aos="fade-right" data-aos-duration="1000">
                                    <Image src="/assets/images/wallets.svg" alt="wallets" width={86} height={86} />
                                </div>
                                <h3 className="text-2xl font-semibold">Wallets</h3>
                                <p className="opacity-50">we support multi-chain wallet. trade from your own wallet, Be your own bank.</p>
                            </div>
                            <ul className="flex gap-3 pt-8 text-base font-medium text-tertiary">
                                <li>Trade Tokens</li>
                                <span>•</span>
                                <li>Mint NFTs</li>
                            </ul>
                        </div>
                        <div className="overflow-hidden border-2 border-secondary bg-secondary/5 p-6 pb-8">
                            <div className="space-y-4">
                                <div data-aos="fade-right" data-aos-duration="1000">
                                    <Image src="/assets/images/multi-sign.svg" alt="multi-sign" width={86} height={86} />
                                </div>
                                <h3 className="text-2xl font-semibold">Multi - sign</h3>
                                <p className="opacity-50">we support multi-chain wallet. trade from your own wallet, Be your own bank.</p>
                            </div>
                            <ul className="flex gap-3 pt-8 text-base font-medium text-secondary">
                                <li>Connect wallet</li>
                                <span>•</span>
                                <li>Trade risk</li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div className="pb-8 pt-14 lg:py-28">
                    <div className="text-center" data-aos="zoom-in" data-aos-duration="1000">
                        <h2 className="text-4xl font-semibold md:text-5xl">All you need is here</h2>
                    </div>
                    <div className="grid-cols-5 items-center gap-12 space-y-10 pt-10 md:grid md:space-y-0 md:pt-20 2xl:items-stretch 2xl:gap-16">
                        <div className="order-2 col-span-2 justify-around gap-4 space-y-6 text-center sm:flex sm:space-y-0 sm:text-left md:flex-col md:justify-between xl:order-1 xl:text-right">
                            <div data-aos="fade-right" data-aos-duration="1000">
                                <div className="mx-auto flex h-24 w-24 items-center justify-center rounded-full bg-white/5 sm:mx-0 xl:ml-auto">
                                    <Image src="/assets/images/trial-account.svg" alt="trial-account" width={50} height={50} />
                                </div>
                                <h3 className="text-xl font-semibold xl:pr-11 xl:text-2xl">Free trial account</h3>
                            </div>
                            <div data-aos="fade-right" data-aos-duration="1000">
                                <div className="mx-auto flex h-24 w-24 items-center justify-center rounded-full bg-white/5 sm:mx-0 xl:ml-auto">
                                    <Image src="/assets/images/plans.svg" alt="plans" height={52} width={52} />
                                </div>
                                <h3 className="text-xl font-semibold xl:pr-11 xl:text-2xl">Affordable plans</h3>
                            </div>
                        </div>
                        <div className="order-1 col-span-5 md:col-span-1 xl:order-2" data-aos="zoom-in" data-aos-duration="1000">
                            <Image src="/assets/images/trade-risk.png" alt="trade-risk" width={208} height={353} className="mx-auto w-52" />
                        </div>
                        <div className="order-3 col-span-2 justify-around gap-4 space-y-6 text-center sm:flex sm:space-y-0 sm:text-left md:flex-col md:justify-between">
                            <div data-aos="fade-left" data-aos-duration="1000">
                                <div className="mx-auto flex h-24 w-24 items-center justify-center rounded-full bg-white/5 sm:mx-0">
                                    <Image src="/assets/images/expert.svg" alt="expert" width={58} height={58} />
                                </div>
                                <h3 className="text-xl font-semibold xl:pl-11 xl:text-2xl">Guided by expert</h3>
                            </div>
                            <div data-aos="fade-left" data-aos-duration="1000">
                                <div className="mx-auto flex h-24 w-24 items-center justify-center rounded-full bg-white/5 sm:mx-0">
                                    <Image src="/assets/images/support.svg" alt="support" width={58} height={58} />
                                </div>
                                <h3 className="text-xl font-semibold xl:pl-11 xl:text-2xl">24/7 live support</h3>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default page;
