import Image from 'next/image';
import Link from 'next/link';
import React from 'react';
import type { Metadata } from 'next';
import helper from '@/libs/helper';

export const metadata: Metadata = {
    title: '404 | Blockchain',
    description: 'OPPS! page not found',
    openGraph: {
        ...helper.openGraphData,
        title: '404 | Blockchain',
        description: 'OPPS! page not found',
        type: 'website',
    },
    twitter: {
        ...helper.twitterData,
        title: '404 | Blockchain',
        description: 'OPPS! page not found',
    },
};

const page = () => {
    return (
        <div className="relative z-1 w-full overflow-hidden pb-5 lg:pl-[300px] lg:pr-4">
            <Image
                src="/assets/images/404-bg.png"
                alt="404bg"
                className="fixed left-auto right-0 bottom-0 w-full max-w-xl opacity-50 md:right-auto md:left-80 xl:opacity-100"
                width={576}
                height={372}
            />
            <div className="container">
                <div className="flex flex-col items-center justify-center gap-10 py-10 xl:flex-row xl:justify-between 2xl:py-0">
                    <div>
                        <div className="pb-16 text-center xl:text-left">
                            <h1
                                className="mb-6 text-4xl font-semibold leading-tight! md:text-5xl xl:pr-10"
                                data-aos="zoom-in-right"
                                data-aos-duration="1000"
                                data-aos-delay="1000"
                            >
                                <span className="animate-text bg-linear-to-r from-[#9A42FE] to-[#23EF9B] bg-clip-text text-transparent">
                                    OPPS! page not found
                                </span>
                            </h1>
                            <p className="font-light leading-7 opacity-60">Looks like this page can’t be found. May be it was removed</p>
                        </div>
                        <div className="text-center xl:text-left">
                            <Link
                                href="/"
                                className="wallet-btn relative inline-flex bg-linear-to-r from-[#9F52FF] to-[#11A9EE] py-4 px-7 text-white transition-all after:absolute after:top-0 after:left-0 after:z-[-1] after:h-full after:w-0 after:duration-500 hover:bg-black hover:from-transparent hover:to-transparent hover:text-white hover:after:left-auto hover:after:right-0 hover:after:w-full md:py-6 md:text-[22px]"
                            >
                                Back to home
                            </Link>
                        </div>
                    </div>
                    <div className="max-w-xl" data-aos="zoom-in" data-aos-duration="1500" data-aos-delay="1000">
                        <Image src="/assets/images/404-banner.png" alt="404image" className="h-full w-full object-cover" width={576} height={576} />
                    </div>
                </div>
            </div>
        </div>
    );
};

export default page;
