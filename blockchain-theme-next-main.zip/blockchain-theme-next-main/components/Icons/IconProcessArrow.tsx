import React from 'react';

const IconProcessArrow = ({className=''}) => {
    return (
        <svg width="90" height="16" viewBox="0 0 90 16" fill="none" className={className}>
            <path
                d="M1 7C0.447715 7 0 7.44772 0 8C0 8.55228 0.447715 9 1 9V7ZM89.7071 8.70711C90.0976 8.31658 90.0976 7.68342 89.7071 7.29289L83.3431 0.928932C82.9526 0.538408 82.3195 0.538408 81.9289 0.928932C81.5384 1.31946 81.5384 1.95262 81.9289 2.34315L87.5858 8L81.9289 13.6569C81.5384 14.0474 81.5384 14.6805 81.9289 15.0711C82.3195 15.4616 82.9526 15.4616 83.3431 15.0711L89.7071 8.70711ZM1 9H89V7H1V9Z"
                fill="white"
            />
        </svg>
    );
};

export default IconProcessArrow;
